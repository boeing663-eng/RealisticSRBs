# RealisticSRBs

RealisticSRBs is a mod for **Kerbal Space Program 1 (KSP1)** that adds configurable thrust-vector gimbal ranges to supported solid rocket boosters (SRBs).

The mod scans supported engine parts, determines their sizes, and generates ModuleManager patches to configure their gimbal ranges.

## Features

- Automatic detection of supported solid rocket boosters.
- Size-based gimbal ranges.
- Automatic generation of ModuleManager patches.
- Support for adding or updating `ModuleGimbal`.
- Logging of detected boosters, assigned sizes, and generated configuration paths.
- Scanning of stock engine parts and Making History engine parts when available.

## Gimbal ranges

| Booster size | Gimbal range |
|---|---:|
| Small | 3° |
| Medium | 5° |
| Large | 7° |

The mod determines part size from available configuration information, using mass as a fallback when necessary.

These ranges specify the configured gimbal limits. Actual thrust-vector movement depends on the part's model and configuration.

## Requirements

- Kerbal Space Program 1.
- ModuleManager 4.2.3 or later.

The Making History expansion is optional.

## Download

Download `RealisticSRBs.zip` from the project's Releases section and extract it.

The ZIP contains the RealisticSRBs project folder. Check the included folder structure before installing the mod.

## Installation

1. Close Kerbal Space Program.
2. Download and extract `RealisticSRBs.zip`.
3. Locate the mod's `RealisticSRBs` folder.
4. Copy the mod folder into your KSP installation's `GameData` directory, ensuring that `RealisticSRBs.dll` is inside `GameData/RealisticSRBs/Plugins/`.
5. Launch KSP and let the mod generate its configuration file.
6. Close KSP and launch it again so ModuleManager can apply the generated patches.

The installed mod should contain at least:

```text
Kerbal Space Program/
└── GameData/
    └── RealisticSRBs/
        ├── Plugins/
        │   └── RealisticSRBs.dll
        └── GeneratedGimbalRanges.cfg
```

The generated configuration file may not exist until the mod has run for the first time.

## How it works

1. The plugin scans supported engine-part configuration files.
2. It identifies compatible solid rocket boosters.
3. It assigns each detected booster a size category and gimbal range.
4. It generates ModuleManager patches in `GeneratedGimbalRanges.cfg`.
5. ModuleManager applies the patches during KSP startup.

**Important:** ModuleManager processes configuration files during startup. If RealisticSRBs generates its configuration after that processing has already happened, you must restart KSP for the generated patches to take effect.

## Troubleshooting

### The mod does not appear to work

- Check that `RealisticSRBs.dll` is in the correct `Plugins` directory.
- Confirm that ModuleManager is installed.
- Check the KSP log for RealisticSRBs startup messages.
- Verify that `GeneratedGimbalRanges.cfg` contains patches for the expected parts.
- Restart KSP after the configuration has been generated.

### A booster does not turn as expected

A configured gimbal range does not guarantee that every part can physically pivot its nozzle. Actual movement depends on the model, thrust transforms, and other part configuration details.

### A booster is missing from the generated configuration

The scanner only recognizes parts that match its supported configuration patterns. Parts using different engine or resource setups may not be detected.

### Another mod changes the gimbal settings

Other mods may modify the same parts or override their gimbal configuration. Check for conflicting ModuleManager patches.

## Known limitations

- Not every solid rocket booster is guaranteed to be detected.
- Configured gimbal ranges do not guarantee physical nozzle movement.
- Other mods may conflict with or override the generated settings.
- Newly generated patches may require another KSP launch before taking effect.

## Compatibility

RealisticSRBs is designed for **Kerbal Space Program 1**. It is not a Kerbal Space Program 2 mod.

Compatibility with individual game versions and other mods may vary.

**RealisticSRBs only supports stock SRBs for now.**

## Source code

The project includes its C# source code and project files. The project targets **.NET Framework 4.7.2** and references KSP game assemblies for development.

## License

See the repository's license file for applicable terms. If no license file is included, contact the author for permission before redistributing or modifying the project.