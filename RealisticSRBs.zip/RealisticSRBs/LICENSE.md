# RealisticSRBs License

## Usage in Other Mods

You are allowed to use, modify, and include RealisticSRBs code in other mods, provided that you follow this requirement:

**You MUST credit laptoppcgamer2016 when using or redistributing code from RealisticSRBs.**

When possible, include a link to the original RealisticSRBs project on SpaceDock.

## Disclaimer

RealisticSRBs is provided "as is", without warranty of any kind. The author is not responsible for problems caused by using this project.

## Third-Party Content

This license only applies to code and content created by laptoppcgamer2016. Third-party files and assets may have their own licenses.
